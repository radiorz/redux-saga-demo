import {rootSaga} from '../saga';


// 环境松耦合
describe('test rootSaga',()=>{
  test('should yield fn',()=>{

  })
})
