beforeEach(()=>{
  const a = 1
})

it('test',()=>{
  expect(a).toBe(1)
})

it('test1',()=>{
  const babel = 2
  expect(babel).toBe(1)
})
